Copyright (C) 2026 Maxmc.
Original code is GPL-3.0-or-later. See LICENSE.txt for terms and warranty disclaimer.
Matching complete source archive: NPCs-Have-Ammo-v1.0.8-source.zip
Source release: https://github.com/mc-hambers/NPCs-Have-Ammo/releases/tag/v1.0.8
