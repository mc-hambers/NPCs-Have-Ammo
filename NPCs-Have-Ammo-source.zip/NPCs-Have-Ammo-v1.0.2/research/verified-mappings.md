# Verified runtime identifiers
Read-only inspection of installed Skyrim.esm and Dawnguard.esm. No game assets are packaged.

- HunterFaction: Skyrim.esm|0004E509
- WEServicesHunterFaction: Skyrim.esm|000AC9C2
- BanditFaction: Skyrim.esm|0001BCC0
- ForswornFaction: Skyrim.esm|00043599
- CurrentFollowerFaction: Skyrim.esm|0005C84E
- LocTypeCity: Skyrim.esm|00013168
- LocTypeBanditCamp: Skyrim.esm|000130DF
- IronArrow: Skyrim.esm|0001397D
- SteelArrow: Skyrim.esm|0001397F
- FalmerArrow: Skyrim.esm|00038341
- DraugrArrow: Skyrim.esm|00034182
- ForswornArrow: Skyrim.esm|000CEE9E

archerClasses
- EncClassThalmorMissile: Skyrim.esm|00072891
- EncClassAlikrMissile: Skyrim.esm|0006766C
- EncClassForswornMissile: Skyrim.esm|00043BCD
- EncClassBanditMissile: Skyrim.esm|00015BE7
- EncClassDraugrMissile: Skyrim.esm|00023C0D
- CombatRanger: Skyrim.esm|00013181
- CombatScout: Skyrim.esm|0001317D

battleClasses
- EncClassDremoraMelee: Skyrim.esm|00017008
- EncClassHorse: Skyrim.esm|0010F71E
- GuardOrc2H: Skyrim.esm|0010E714
- CWSoldierClass: Skyrim.esm|0010B1D8
- EncClassBear: Skyrim.esm|00106AED
- CombatNightingale: Skyrim.esm|000FB0DA
- EncClassMammoth: Skyrim.esm|000F2594
- EncClassHorker: Skyrim.esm|000EDD36
- CombatMageNecro: Skyrim.esm|000C969F
- EncClassWerewolfBoss: Skyrim.esm|000A1995
- EncClassWerewolfMage: Skyrim.esm|000A1994
- EncClassWerewolf: Skyrim.esm|000A1993
- EncClassMudCrab: Skyrim.esm|000BB4B0
- EncClassAtronachStorm: Skyrim.esm|000AD237
- EncClassAtronachFrost: Skyrim.esm|000AD236
- EncClassAtronachFlame: Skyrim.esm|000AD235
- EncClassGiant: Skyrim.esm|000ABB44
- EncClassHagraven: Skyrim.esm|000A93B3
- EncClassDwarvenSpider: Skyrim.esm|00090359
- EncClassDwarvenSphere: Skyrim.esm|00090358
- EncClassDwarvenCenturion: Skyrim.esm|00090356
- EncClassPenitusOculatus: Skyrim.esm|0007D98D
- EncClassThalmorMelee: Skyrim.esm|0007289D
- EncClassThalmorMissile: Skyrim.esm|00072891
- EncClassThalmorWizard: Skyrim.esm|00072887
- EncClassIceWraith: Skyrim.esm|00073F1F
- EncClassAlikrWizard: Skyrim.esm|0006766D
- EncClassAlikrMissile: Skyrim.esm|0006766C
- EncClassAlikrMelee: Skyrim.esm|0006766B
- EncClassVampire: Skyrim.esm|0002E00F
- EncClassFrostbiteSpider: Skyrim.esm|00044CCB
- EncClassChaurus: Skyrim.esm|00044CCA
- EncClassForswornMissile: Skyrim.esm|00043BCD
- EncClassForswornShaman: Skyrim.esm|00043BCC
- EncClassForsworn: Skyrim.esm|00043BCB
- EncClassBanditMissile: Skyrim.esm|00015BE7
- EncClassBanditWizard: Skyrim.esm|00039D30
- EncClassDragon: Skyrim.esm|0002F201
- EncClassDraugrMagic: Skyrim.esm|00023C0E
- EncClassDraugrMissile: Skyrim.esm|00023C0D
- EncClassDraugrMelee: Skyrim.esm|00023C0C
- GuardOrc1H: Skyrim.esm|0002A477
- GuardSonsSkyrim: Skyrim.esm|000253F3
- GuardImperial: Skyrim.esm|000253F2
- CombatMageDestruction: Skyrim.esm|0001E7D0
- EncClassFalmerShaman: Skyrim.esm|0001CE1F
- EncClassFalmer: Skyrim.esm|0001CE1E
- EncClassAnimalPrey: Skyrim.esm|0001CE1D
- EncClassDragonPriest: Skyrim.esm|0001CE1C
- EncClassBanditMelee: Skyrim.esm|0001CE17
- CombatBarbarian: Skyrim.esm|0001CE16
- CombatWarrior2H: Skyrim.esm|0001CE15
- CombatMageConjurer: Skyrim.esm|0001CE14
- SoldierSonsSkyrimNotGuard: Skyrim.esm|00013280
- SoldierImperialNotGuard: Skyrim.esm|0001327F
- EncClassAnimalPredator: Skyrim.esm|000131E6
- CombatMonk: Skyrim.esm|00013182
- CombatRanger: Skyrim.esm|00013181
- CombatRogue: Skyrim.esm|00013180
- CombatAssassin: Skyrim.esm|0001317F
- CombatThief: Skyrim.esm|0001317E
- CombatScout: Skyrim.esm|0001317D
- CombatNightblade: Skyrim.esm|0001317C
- CombatMystic: Skyrim.esm|0001317B
- CombatMageElemental: Skyrim.esm|0001317A
- CombatSorcerer: Skyrim.esm|00013179
- CombatWitchblade: Skyrim.esm|00013178
- CombatSpellsword: Skyrim.esm|00013177
- CombatWarrior1H: Skyrim.esm|00013176

guardClasses
- GuardOrc2H: Skyrim.esm|0010E714
- GuardOrc1H: Skyrim.esm|0002A477
- GuardSonsSkyrim: Skyrim.esm|000253F3
- GuardImperial: Skyrim.esm|000253F2

falmerRaces
- FalmerRace: Skyrim.esm|000131F4

undeadRaces
- DraugrMagicRace: Skyrim.esm|000F71DC
- SkeletonNecroPriestRace: Skyrim.esm|000EBE18
- SkeletonNecroRace: Skyrim.esm|000EB872
- RigidSkeletonRace: Skyrim.esm|000B9FD7
- SkeletonRace: Skyrim.esm|000B7998
- DraugrRace: Skyrim.esm|00000D53

- DLC1BoltSteel: Dawnguard.esm|000BB3
- DLC1BoltDwarven: Dawnguard.esm|00D099
- Installed SkyrimSE.exe contains the exact setting name bForceNPCsUseAmmo:Combat (read-only string check).
- The linked CommonLib Setting API supplies GetType/SetBool; no user INI file is written.
