# Implemented decisions

User request: separate SKSE arrow/bolt mod, force global NPC ammo consumption, hunter/archer/bow eligibility, location/occupation-based timers and caps, smart native ammo selection, no player-gift type propagation. Clarifications: a city entry can expire a timer immediately; followers participate and take twice as long between restocks (corrected from the earlier fast-follower interpretation). Dynamic Pickpocket Loot remains unchanged.

- Initial fill uses cap minus current amount, as in the deferred arrow design. Periodic additions use floor(cap/2), capped by deficit, and never remove anything.
- Arrows and bolts have separate caps/timers. Crossbow-only actors use bolts; known archer/hunter roles missing weapons can infer a crossbow from their native list or default to arrows.
- Random interval position is saved once per cycle. Changing location or follower speed rescales the remaining fraction. The first observed outside-to-city transition then subtracts one whole game day, once for that cycle. An overdue timer stays due; long absences yield one refill only.
- Cities use LocTypeCity ancestry; villages tagged only LocTypeTown are not automatically cities. Camp rate requires a bandit/Forsworn faction and LocTypeBanditCamp ancestry. Genuine guard status or mapped guard classes take guard timing priority.
- Lowest gold value is primary, highest base damage breaks equal-price ties, Form ID breaks exact ties. No target-resistance/effect simulation is claimed.
- Falmer/ancient-Nord/Forsworn vanilla species types are restricted and have native fallbacks. Custom inventory/list ammo is trusted as authored for that actor. Ordinary sport fallback is iron/steel, battle steel/iron, bolts steel/dwarven.
- Player transfers are protected by saved quantities. Only unprotected current quantities can seed selection, but a native list may independently allow the same type. Merged physical identities and pre-installation gifts cannot be reconstructed.
- The runtime INI boolean is enforced through CommonLib, without writing user settings or adding an ESP. Setting failures pause restocking. It applies globally, so noneligible special NPC weapons need live tests too.
- Own DLL, log, save schema 2 (schema-1 migration supported), serialization ID 0x4E484131 and record ID 0x414D4D4F. No dependency on the loot DLL. The same reset hook slots can be chained; compatibility still needs gameplay verification.

- Follower cap clarification: store native/default and combat caps separately per ammo kind. Active followers use combat 40�60, and dismissal restores the saved native cap. Already-combat defaults reuse that roll. Cap changes do not reset timers, refill immediately, remove excess ammo, or reroll on repeated recruitment. The runtime default-occupation flag remains separate from follower status so NPCs first encountered following can later restore their proper default.
